include_guard(GLOBAL)

set(OCTARYN_LINUX_FAMILY "Debian")
octaryn_arch_select(OCTARYN_TARGET_DOTNET_RID linux-x64 linux-arm64)
