if(OCTARYN_DOTNET_HOSTING_AVAILABLE)
    add_custom_target(octaryn_run_client_launch_probe
        COMMAND "${CMAKE_COMMAND}" -E env
            "$<TARGET_FILE:octaryn_client_launch_probe>"
        DEPENDS
            octaryn_client_bundle
            octaryn_client_launch_probe
        WORKING_DIRECTORY "${OCTARYN_WORKSPACE_ROOT_DIR}"
        VERBATIM)
else()
    add_custom_target(octaryn_run_client_launch_probe
        COMMAND "${CMAKE_COMMAND}" -E echo "Skipping client launch probe: .NET native hosting unavailable for ${OCTARYN_TARGET_PLATFORM}."
        VERBATIM)
endif()

if(OCTARYN_DOTNET_HOSTING_AVAILABLE AND OCTARYN_TARGET_PLATFORM STREQUAL "Linux" AND OCTARYN_TARGET_ARCH STREQUAL "x64")
    add_custom_target(octaryn_run_client_app_launch_probe
        COMMAND "${CMAKE_COMMAND}" -E rm -f
            "${octaryn_client_app_probe_log}"
        COMMAND "${CMAKE_COMMAND}" -E env
            "OCTARYN_CLIENT_APP_LOG_PATH=${octaryn_client_app_probe_log}"
            "OCTARYN_CLIENT_CHUNK_STREAM_PATH=${octaryn_client_app_probe_radius32_chunk_stream}"
            "SDL_VIDEODRIVER=x11"
            "${octaryn_client_app_bundle_output}"
        DEPENDS
            octaryn_client_bundle
        WORKING_DIRECTORY "${OCTARYN_WORKSPACE_ROOT_DIR}"
        VERBATIM)
    add_custom_target(octaryn_validate_client_app_launch_probe
        COMMAND "${CMAKE_COMMAND}" -E rm -f
            "${octaryn_client_app_probe_log}"
        COMMAND "${CMAKE_COMMAND}" -E env
            "OCTARYN_CLIENT_APP_LOG_PATH=${octaryn_client_app_probe_log}"
            "OCTARYN_CLIENT_CHUNK_STREAM_PATH=${octaryn_client_app_probe_radius32_chunk_stream}"
            "SDL_VIDEODRIVER=x11"
            "${octaryn_client_app_bundle_output}"
        COMMAND python3
            "${OCTARYN_WORKSPACE_ROOT_DIR}/tools/validation/validate_client_app_launch_probe_log.py"
            --log-file "${octaryn_client_app_probe_log}"
        DEPENDS
            octaryn_client_bundle
        WORKING_DIRECTORY "${OCTARYN_WORKSPACE_ROOT_DIR}"
        VERBATIM)
else()
    add_custom_target(octaryn_run_client_app_launch_probe
        COMMAND "${CMAKE_COMMAND}" -E echo "Skipping client app launch probe: Slang RHI bootstrap execution is only active for Linux/x64 targets with .NET native hosting."
        VERBATIM)
    add_custom_target(octaryn_validate_client_app_launch_probe
        COMMAND "${CMAKE_COMMAND}" -E echo "Skipping client app launch probe validation: Slang RHI bootstrap execution is only active for Linux/x64 targets with .NET native hosting."
        VERBATIM)
endif()
