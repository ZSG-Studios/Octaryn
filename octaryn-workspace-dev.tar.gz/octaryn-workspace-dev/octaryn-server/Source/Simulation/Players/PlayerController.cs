using Octaryn.Server.Persistence.WorldBlocks;
using Octaryn.Server.World.Blocks;
using Octaryn.Shared.Host;
using Octaryn.Shared.World;

namespace Octaryn.Server.Simulation.Players;

internal sealed class PlayerController : IDisposable
{
    private const int PlayerId = 1;

    private readonly string _playerDirectory;
    private readonly NativePlayerSimulation _simulation;
    private IntPtr _session;

    public PlayerController(
        string playerDirectory,
        BlockStore blocks,
        IBlockAuthorityRules blockRules,
        Func<BlockPosition, BlockId>? generatedBlocks = null)
    {
        _playerDirectory = playerDirectory;
        _simulation = new NativePlayerSimulation(blocks, blockRules, generatedBlocks);
        _session = NativePlayerSimulation.CreateSession(
            LoadInitialState(playerDirectory, out var loadedFromSave),
            loadedFromSave);
        var state = NativePlayerSimulation.StateFromSession(_session);
        LiveDebugLog.Write(
            $"server_live_player_load loaded={(loadedFromSave ? 1 : 0)} " +
            $"pos=({state.X:F3},{state.Y:F3},{state.Z:F3}) " +
            $"pitch={state.Pitch:F6} yaw={state.Yaw:F6} selected_block={state.SelectedBlock.Value}");
    }

    public PlayerState Snapshot()
    {
        ThrowIfDisposed();
        return NativePlayerSimulation.StateFromSession(_session);
    }

    public bool PlacementIntersectsPlayer(HostCommand command)
    {
        ThrowIfDisposed();
        if (command.Kind != HostCommandKind.SetBlock || command.D == 0)
        {
            return false;
        }

        return NativePlayerSimulation.SessionIntersectsBlock(_session, command.A, command.B, command.C);
    }

    public void AlignSpawnToSurface()
    {
        ThrowIfDisposed();
        var loadedFromSave = NativePlayerSimulation.SessionLoadedFromSave(_session);
        if (!_simulation.TryAlignSpawnToSurface(
            _session,
            out var aligned,
            out var adjusted,
            out var surfaceY,
            out var surfaceBlock))
        {
            LiveDebugLog.Write(
                $"server_live_player_spawn_align active=0 reason=missing_surface " +
                $"loaded={(loadedFromSave ? 1 : 0)} pos=({aligned.X:F3},{aligned.Y:F3},{aligned.Z:F3})");
            return;
        }

        var persisted = SaveIfDue(0.0, force: true);
        LiveDebugLog.Write(
            $"server_live_player_spawn_align active=1 adjusted={(adjusted ? 1 : 0)} " +
            $"loaded={(loadedFromSave ? 1 : 0)} surface_y={surfaceY} surface_block={surfaceBlock.Value} " +
            $"eye_y={aligned.Y:F3} saved={(persisted ? 1 : 0)}");
    }

    public void Tick(in HostFrameContext frame)
    {
        var input = frame.Input;
        ThrowIfDisposed();
        var state = _simulation.Step(_session, input, frame.DeltaSeconds, out var tickResult);
        var persisted = SaveIfDue(frame.DeltaSeconds);
        LiveDebugLog.Write(
            $"server_live_player_state frame={frame.FrameIndex} tick_input={tickResult.TickInput} authority=server " +
            $"mode={NativePlayerSimulation.ControlModeName(state.ControlMode)} flags={input.Flags} controller={input.Controller} " +
            $"move=({input.MoveX:F3},{input.MoveY:F3},{input.MoveZ:F3}) " +
            $"client_camera=({input.CameraX:F3},{input.CameraY:F3},{input.CameraZ:F3},{input.CameraPitch:F6},{input.CameraYaw:F6}) " +
            $"pos=({state.X:F3},{state.Y:F3},{state.Z:F3}) " +
            $"delta=({tickResult.DeltaX:F3},{tickResult.DeltaY:F3},{tickResult.DeltaZ:F3}) " +
            $"pitch={state.Pitch:F6} yaw={state.Yaw:F6} " +
            $"velocity=({state.VelocityX:F3},{state.VelocityY:F3},{state.VelocityZ:F3}) " +
            $"ground={(state.IsOnGround ? 1 : 0)} saved={(persisted ? 1 : 0)}");
        LogMotionDiagnostics(in frame, state, tickResult);
    }

    private static void LogMotionDiagnostics(
        in HostFrameContext frame,
        PlayerState state,
        NativeTickResult tickResult)
    {
        var input = frame.Input;
        var inputMagnitude = MathF.Sqrt(
            (input.MoveX * input.MoveX) +
            (input.MoveY * input.MoveY) +
            (input.MoveZ * input.MoveZ));
        if (tickResult.TickInput == 0 || inputMagnitude <= 0.001f)
        {
            return;
        }

        var deltaMagnitude = MathF.Sqrt(
            (tickResult.DeltaX * tickResult.DeltaX) +
            (tickResult.DeltaY * tickResult.DeltaY) +
            (tickResult.DeltaZ * tickResult.DeltaZ));
        var cameraErrorX = input.CameraX - state.X;
        var cameraErrorY = input.CameraY - state.Y;
        var cameraErrorZ = input.CameraZ - state.Z;
        var horizontalCameraError = MathF.Sqrt(
            (cameraErrorX * cameraErrorX) + (cameraErrorZ * cameraErrorZ));
        var stalled = deltaMagnitude <= 0.001f ? 1 : 0;
        LiveDebugLog.Write(
            $"server_live_player_motion_profile frame={frame.FrameIndex} dt={frame.DeltaSeconds:F6} " +
            $"input_len={inputMagnitude:F3} delta_len={deltaMagnitude:F3} stalled={stalled} " +
            $"camera_error=({cameraErrorX:F3},{cameraErrorY:F3},{cameraErrorZ:F3}) " +
            $"horizontal_camera_error={horizontalCameraError:F3}");
    }

    private bool SaveIfDue(double deltaSeconds, bool force = false)
    {
        var decision = NativePlayerSimulation.SaveDecision(_session, deltaSeconds, force);
        if (decision.ShouldSave == 0)
        {
            return false;
        }

        var saveState = NativePlayerSimulation.SaveStateFromSessionSaveResult(decision);
        NativeWorldPersistenceLibrary.WritePlayerDirectoryEntry(_playerDirectory, PlayerId, saveState);
        NativePlayerSimulation.NoteSaved(_session, saveState);
        return true;
    }

    public void Dispose()
    {
        var session = _session;
        _session = IntPtr.Zero;
        NativePlayerSimulation.DestroySession(session);
    }

    private void ThrowIfDisposed()
    {
        if (_session == IntPtr.Zero)
        {
            throw new ObjectDisposedException(nameof(PlayerController));
        }
    }

    private static PlayerState LoadInitialState(string playerDirectory, out bool loadedFromSave)
    {
        if (NativeWorldPersistenceLibrary.TryReadPlayerDirectoryEntry(playerDirectory, PlayerId, out var saved) &&
            NativePlayerSimulation.TryCreateStateFromSave(saved, out var state))
        {
            loadedFromSave = true;
            return state;
        }

        loadedFromSave = false;
        return NativePlayerSimulation.DefaultState();
    }
}
