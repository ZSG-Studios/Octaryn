#include "RenderBackend.h"

#include "SlangRhiDevice.h"
#include "SlangRhiFrameResources.h"

namespace octaryn::client::rendering {

RenderBackendStatus active_render_backend_status() {
  const SlangRhiDeviceProbeResult slang = probe_slang_rhi_device();
  const SlangRhiFrameResourceProbeResult frame =
      probe_slang_rhi_frame_resources();
  const bool frame_lifecycle_validated =
      frame.frame_begun && frame.frame_encoded && frame.frame_ended &&
      frame.submitted && frame.fence_completed;
  return RenderBackendStatus{RenderBackendKind::SlangRhi,
                             true,
                             false,
                             false,
                             slang.runtime_available,
                             slang.device_created,
                             frame.readback_valid,
                             frame.frame_begun,
                             frame.frame_encoded,
                             frame.frame_ended,
                             frame.submitted,
                             frame_lifecycle_validated,
                             slang.status,
                             frame.status};
}

const char *render_backend_name(RenderBackendKind kind) {
  switch (kind) {
  case RenderBackendKind::SlangRhi:
    return "slang_rhi";
  }
  return "unknown";
}

} // namespace octaryn::client::rendering
