#include "SlangRhiSwapchain.h"

#include <SDL3/SDL.h>

#if defined(OCTARYN_CLIENT_SLANG_RHI_AVAILABLE)
#include <slang-com-ptr.h>
#include <slang-gfx.h>
#endif

#include <cstdint>

namespace octaryn::client::rendering {

#if defined(OCTARYN_CLIENT_SLANG_RHI_AVAILABLE)
namespace {

bool result_succeeded(SlangResult result) { return SLANG_SUCCEEDED(result); }

} // namespace
#endif

SlangRhiSwapchainProbeResult probe_slang_rhi_xlib_swapchain() {
  SlangRhiSwapchainProbeResult probe{false, false, false, false, false,
                                     false, false, false, "uninitialized",
                                     "not_started"};
#if !defined(OCTARYN_CLIENT_SLANG_RHI_AVAILABLE)
  probe.status = "runtime_unavailable";
  return probe;
#else
  if (!SDL_InitSubSystem(SDL_INIT_VIDEO)) {
    probe.status = "sdl_video_init_failed";
    return probe;
  }
  probe.sdl_video_initialized = true;
  probe.video_driver = SDL_GetCurrentVideoDriver();
  if (probe.video_driver == nullptr) {
    probe.video_driver = "unknown";
  }

  SDL_Window *window = SDL_CreateWindow("Octaryn Slang RHI swapchain probe", 64,
                                        64, SDL_WINDOW_HIDDEN);
  if (window == nullptr) {
    probe.status = "window_create_failed";
    SDL_QuitSubSystem(SDL_INIT_VIDEO);
    return probe;
  }
  probe.window_created = true;

  SDL_PropertiesID properties = SDL_GetWindowProperties(window);
  void *xdisplay = SDL_GetPointerProperty(
      properties, SDL_PROP_WINDOW_X11_DISPLAY_POINTER, nullptr);
  const std::int64_t xwindow_value = SDL_GetNumberProperty(
      properties, SDL_PROP_WINDOW_X11_WINDOW_NUMBER, 0);
  if (xdisplay == nullptr || xwindow_value == 0) {
    probe.status = "xlib_window_handle_unavailable";
    SDL_DestroyWindow(window);
    SDL_QuitSubSystem(SDL_INIT_VIDEO);
    return probe;
  }
  probe.xlib_handle_available = true;

  gfx::IDevice::Desc device_desc{};
  device_desc.deviceType = gfx::DeviceType::Default;
  Slang::ComPtr<gfx::IDevice> device;
  if (!result_succeeded(gfx::gfxCreateDevice(&device_desc, device.writeRef())) ||
      device == nullptr) {
    probe.status = "device_create_failed";
    SDL_DestroyWindow(window);
    SDL_QuitSubSystem(SDL_INIT_VIDEO);
    return probe;
  }
  probe.device_created = true;

  gfx::ICommandQueue::Desc queue_desc{};
  queue_desc.type = gfx::ICommandQueue::QueueType::Graphics;
  Slang::ComPtr<gfx::ICommandQueue> queue;
  if (!result_succeeded(device->createCommandQueue(queue_desc, queue.writeRef())) ||
      queue == nullptr) {
    probe.status = "queue_create_failed";
    SDL_DestroyWindow(window);
    SDL_QuitSubSystem(SDL_INIT_VIDEO);
    return probe;
  }
  probe.queue_created = true;

  gfx::ISwapchain::Desc swapchain_desc{};
  swapchain_desc.format = gfx::Format::R8G8B8A8_UNORM;
  swapchain_desc.width = 64;
  swapchain_desc.height = 64;
  swapchain_desc.imageCount = 2;
  swapchain_desc.queue = queue;
  swapchain_desc.enableVSync = false;
  const gfx::WindowHandle handle = gfx::WindowHandle::FromXWindow(
      xdisplay, static_cast<std::uint32_t>(xwindow_value));
  Slang::ComPtr<gfx::ISwapchain> swapchain;
  if (!result_succeeded(
          device->createSwapchain(swapchain_desc, handle, swapchain.writeRef())) ||
      swapchain == nullptr) {
    probe.status = "swapchain_create_failed";
    SDL_DestroyWindow(window);
    SDL_QuitSubSystem(SDL_INIT_VIDEO);
    return probe;
  }
  probe.swapchain_created = true;

  const int image_index = swapchain->acquireNextImage();
  if (image_index < 0) {
    probe.status = "swapchain_image_acquire_failed";
    swapchain.setNull();
    SDL_DestroyWindow(window);
    SDL_QuitSubSystem(SDL_INIT_VIDEO);
    return probe;
  }
  probe.image_acquired = true;

  if (!result_succeeded(swapchain->present())) {
    probe.status = "swapchain_present_failed";
    swapchain.setNull();
    SDL_DestroyWindow(window);
    SDL_QuitSubSystem(SDL_INIT_VIDEO);
    return probe;
  }
  probe.presented = true;

  swapchain.setNull();
  SDL_DestroyWindow(window);
  SDL_QuitSubSystem(SDL_INIT_VIDEO);
  probe.status = "swapchain_present_validated";
  return probe;
#endif
}

} // namespace octaryn::client::rendering
