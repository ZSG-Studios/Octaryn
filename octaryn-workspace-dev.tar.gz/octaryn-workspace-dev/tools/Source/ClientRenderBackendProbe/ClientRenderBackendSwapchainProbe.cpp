#include "SlangRhiSwapchain.h"

#include <cstdio>

int main() {
  const auto result =
      octaryn::client::rendering::probe_slang_rhi_xlib_swapchain();

  if (!result.swapchain_created || !result.image_acquired ||
      !result.presented) {
    std::fprintf(stderr,
                 "client render backend swapchain probe failed: status=%s "
                 "driver=%s sdl=%d window=%d xlib=%d device=%d queue=%d "
                 "swapchain=%d acquired=%d presented=%d\n",
                 result.status, result.video_driver,
                 result.sdl_video_initialized ? 1 : 0,
                 result.window_created ? 1 : 0,
                 result.xlib_handle_available ? 1 : 0,
                 result.device_created ? 1 : 0,
                 result.queue_created ? 1 : 0,
                 result.swapchain_created ? 1 : 0,
                 result.image_acquired ? 1 : 0, result.presented ? 1 : 0);
    return 1;
  }

  std::printf("client_render_backend_swapchain_probe=passed driver=%s "
              "status=%s swapchain=created acquired=1 presented=1\n",
              result.video_driver, result.status);
  return 0;
}
