#!/usr/bin/env python3
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ENTRY_POINTS = (
    ("Voxel/VoxelFacePull.vert.slang", "vertex"),
    ("Voxel/VoxelOccupancyProbe.slang", "compute"),
    ("Voxel/VoxelFaceMaskProbe.slang", "compute"),
    ("Voxel/VoxelGreedyCountProbe.slang", "compute"),
    ("Voxel/VoxelPrefixScanProbe.slang", "compute"),
    ("Voxel/VoxelPackedQuadEmitProbe.slang", "compute"),
    ("Voxel/VoxelIndirectGenerationProbe.slang", "compute"),
    ("Voxel/VoxelRasterProbe.slang", "vertex"),
    ("Voxel/VoxelRasterProbe.slang", "fragment"),
    ("Voxel/VoxelDepth.frag.slang", "fragment"),
    ("Voxel/VoxelPbr.frag.slang", "fragment"),
    ("Voxel/VoxelVisibility.frag.slang", "fragment"),
)

FORBIDDEN_PLACEHOLDER_SNIPPETS = (
    "float4(0.0, 0.0, 0.0, 1.0)",
    "float4(1.0, 1.0, 1.0, 1.0)",
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--slangc", default=None)
    args = parser.parse_args()

    slangc = args.slangc or shutil.which("slangc")
    if not slangc:
        print("slangc was not found in PATH; Slang shader validation cannot run", file=sys.stderr)
        return 1

    errors: list[str] = []
    args.output_dir.mkdir(parents=True, exist_ok=True)

    active_shader_files = sorted(path for path in args.source_root.rglob("*") if path.is_file())
    non_slang_sources = [path.relative_to(args.source_root).as_posix() for path in active_shader_files if path.suffix != ".slang"]
    if non_slang_sources:
        errors.append(f"active shader tree must be Slang-only; non-Slang files found: {non_slang_sources}")

    for relative, stage in ENTRY_POINTS:
        source = args.source_root / relative
        if not source.exists():
            errors.append(f"missing Slang entry source: {source}")
            continue
        source_text = source.read_text()
        for snippet in FORBIDDEN_PLACEHOLDER_SNIPPETS:
            if snippet in source_text:
                errors.append(f"{source}: forbidden placeholder shader output {snippet!r}")
        output = args.output_dir / (relative.replace("/", "_") + ".spv")
        command = [
            slangc,
            str(source),
            "-I",
            str(args.source_root),
            "-I",
            str(source.parent),
            "-entry",
            "vertex_main" if relative.endswith("VoxelRasterProbe.slang") and stage == "vertex"
            else "fragment_main" if relative.endswith("VoxelRasterProbe.slang") and stage == "fragment"
            else "main",
            "-stage",
            stage,
            "-target",
            "spirv",
            "-o",
            str(output),
        ]
        result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if result.returncode != 0:
            errors.append(f"slangc failed for {source} ({stage}) with exit {result.returncode}:\n{result.stdout}")
        elif not output.exists() or output.stat().st_size == 0:
            errors.append(f"slangc produced no SPIR-V output for {source}")

    if errors:
        for error in errors:
            print(error, file=sys.stderr)
        return 1

    print(f"client_slang_shader_validation=passed entry_points={len(ENTRY_POINTS)} slangc={slangc}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
