return BinarySandboxProbe.Run(args);
