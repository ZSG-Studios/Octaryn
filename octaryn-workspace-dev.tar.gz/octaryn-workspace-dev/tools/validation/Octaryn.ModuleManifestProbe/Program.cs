return ManifestProbe.Run(args);
