"""Basegame atlas builder internals."""
